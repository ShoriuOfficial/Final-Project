

// let arr = [{ category: "asus", ram: 22, model: 56 },
// { category: "asus", ram: 22, model: 56 },
// { category: "hp", ram: 22, model: 56 },
// { category: 'asus', ram: 22, model: 56 }
// ]



document.getElementById("addComputer").addEventListener("click", (e) => {
    e.preventDefault()
    let addComputerForm = document.getElementById("addComputerForm")
    let formData = new FormData(addComputerForm)
    let formObj = {}
    for (const [key, value] of formData) {
        formObj[key] = value
    }
    console.log(formObj);

    let myComputers = localStorage.getItem("myComputers") ? JSON.parse(localStorage.getItem("myComputers")) : []
    myComputers.push(formObj)
    localStorage.setItem("myComputers", JSON.stringify(myComputers))
   
    let tableDataArray = localStorage.getItem("myComputers") ? JSON.parse(localStorage.getItem("myComputers")) : []
    document.getElementById("addComputerTableBody").innerHTML = ""
    tableDataArray.forEach(obj => {
        let newTr = document.createElement("tr")
        newTr.innerHTML = `<td>${obj.id}</td><td>${obj.name}</td><td>${obj.ram}</td><td>${obj.ram}</td><td>${obj.category}</td>`
    
        document.getElementById("addComputerTableBody").append(newTr)
    });

})

let filt = JSON.parse(localStorage.getItem("myComputers")).filter((obj)=>{
   return obj.ram = "Yusif"
})
console.log(filt);

