
        // Alert

        let button = document.getElementById('button')
        let alerts = document.getElementById('success');
        button.addEventListener('click', () => {
            // success.innerHTML = '<div class="alert alert-success" id="alert-success" role="alert">Uğurlu qeydiyyat!</div>'
        });
        document.getElementById("button").addEventListener("click", function (event) {
            // event.preventDefault()
        });

        // localStorage

        button.addEventListener('click', () => {
            // localStorage.setItem('uname', uname.value, 'email', email.value, 'pswd', pswd.value, 'numbr', numbr.value)
            alert('Giriş başarılı!');
        });

        //None
        localStorage.clear()